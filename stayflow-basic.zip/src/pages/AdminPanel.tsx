import React from 'react';
import { useAuth } from '../services/AuthContext';
import { ShieldCheck, Plus, Settings } from 'lucide-react';

export function AdminPanel() {
  const { user } = useAuth();

  if (user?.role !== 'admin') {
    return (
      <div className="flex flex-col items-center justify-center p-20">
        <ShieldCheck className="h-16 w-16 text-red-500 mb-4" />
        <h2 className="text-2xl font-bold">Access Denied</h2>
        <p className="text-gray-500">Only administrators can access this panel.</p>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      <div className="flex justify-between items-center mb-10">
        <div>
          <h1 className="text-4xl font-bold tracking-tight">Admin Dashboard</h1>
          <p className="text-gray-500 mt-2">Manage properties, bookings, and system settings.</p>
        </div>
        <button className="inline-flex items-center space-x-2 px-6 py-3 bg-blue-600 text-white font-bold rounded-2xl hover:bg-blue-700 transition-all shadow-lg shadow-blue-500/20">
          <Plus className="h-5 w-5" />
          <span>Add Property</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="bg-white border border-gray-100 p-8 rounded-3xl shadow-sm">
          <Settings className="h-8 w-8 text-blue-600 mb-4" />
          <h3 className="text-xl font-bold mb-2">Property Management</h3>
          <p className="text-gray-500 text-sm mb-6">Edit, update or remove existing property listings.</p>
          <button className="text-blue-600 font-bold hover:underline">View Properties</button>
        </div>
        
        <div className="bg-white border border-gray-100 p-8 rounded-3xl shadow-sm">
          <Plus className="h-8 w-8 text-green-600 mb-4" />
          <h3 className="text-xl font-bold mb-2">Booking Reports</h3>
          <p className="text-gray-500 text-sm mb-6">View all system-wide bookings and occupancy rates.</p>
          <button className="text-blue-600 font-bold hover:underline">View Bookings</button>
        </div>

        <div className="bg-white border border-gray-100 p-8 rounded-3xl shadow-sm">
          <ShieldCheck className="h-8 w-8 text-purple-600 mb-4" />
          <h3 className="text-xl font-bold mb-2">User Roles</h3>
          <p className="text-gray-500 text-sm mb-6">Manage user permissions and administrative access.</p>
          <button className="text-blue-600 font-bold hover:underline">Manage Users</button>
        </div>
      </div>
    </div>
  );
}
