import React, { useEffect, useState } from 'react';
import { collection, query, getDocs, addDoc, limit } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Hotel, Restaurant } from '../types';
import { motion } from 'motion/react';
import { Hotel as HotelIcon, Utensils, Map as MapIcon, ArrowRight, Loader2, Star, MapPin } from 'lucide-react';
import { Link } from 'react-router-dom';

export function Home() {
  const [hotels, setHotels] = useState<Hotel[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchData() {
      try {
        const hSnap = await getDocs(query(collection(db, 'hotels'), limit(6)));
        const fetched = hSnap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Hotel));
        setHotels(fetched);
      } catch (error) {
        console.error('Error fetching data:', error);
      } finally {
        setLoading(false);
      }
    }
    fetchData();
  }, []);

  const seedData = async () => {
     const HOTELS_SEED = [
      { name: "The Oberoi Grand", description: "Classic luxury in Kolkata.", city: "Kolkata", state: "West Bengal", price: 12500, rating: 4.8, image: "https://images.unsplash.com/photo-1566073771259-6a8506099945?w=800", amenities: ["WiFi", "Pool", "Spa"] },
      { name: "Taj Mahal Palace", description: "Iconic Mumbai landmark.", city: "Mumbai", state: "Maharashtra", price: 35000, rating: 4.9, image: "https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?w=800", amenities: ["Heritage", "Butler", "Ocean View"] },
      { name: "ITC Grand Chola", description: "Architectural splendor in Chennai.", city: "Chennai", state: "Tamil Nadu", price: 18000, rating: 4.7, image: "https://images.unsplash.com/photo-1571896349842-33c89424de2d?w=800", amenities: ["Dining", "Golf", "Spa"] }
    ];
    const RESTAURANTS_SEED = [
      { name: "Bukhara", city: "New Delhi", cuisine: "North Indian", rating: 4.9, costForTwo: 7000, image: "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=800" },
      { name: "Indian Accent", city: "New Delhi", cuisine: "Modern Indian", rating: 4.8, costForTwo: 10000, image: "https://images.unsplash.com/photo-1552566626-52f8b828add9?w=800" }
    ];

    try {
      setLoading(true);
      for (const h of HOTELS_SEED) await addDoc(collection(db, 'hotels'), h);
      for (const r of RESTAURANTS_SEED) await addDoc(collection(db, 'restaurants'), r);
      window.location.reload();
    } catch (e) {
      alert('Data simulation failed. This usually happens if Firestore rules deny public writes.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-[#050505] min-h-screen">
      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&q=80&w=2000" 
            className="w-full h-full object-cover grayscale brightness-[0.3]" 
            alt="Hero Background" 
          />
          <div className="absolute inset-0 bg-gradient-to-b from-[#050505]/60 via-transparent to-[#050505]" />
          <div className="absolute top-1/4 -left-1/4 w-1/2 h-1/2 bg-accent/10 blur-[150px] rounded-full" />
        </div>

        <div className="relative z-10 text-center px-6">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <span className="text-[10px] uppercase tracking-[8px] text-accent font-bold mb-6 block">The Ultimate Voyager Experience</span>
            <h1 className="text-7xl md:text-9xl font-serif italic text-text-bright mb-10 tracking-tighter">StayFlow.</h1>
            <p className="text-text-dim max-w-xl mx-auto text-lg font-light leading-relaxed mb-12">
              Curating architectural marvels and culinary landmarks for the contemporary soul.
            </p>
            <div className="flex flex-wrap justify-center gap-8">
              <Link to="/hotels" className="px-12 py-6 bg-accent text-black font-bold uppercase tracking-[3px] text-[11px] hover:bg-white transition-all shadow-2xl active:scale-95">
                Explore Stays
              </Link>
              <Link to="/restaurants" className="px-12 py-6 bg-transparent border border-white/20 text-white font-bold uppercase tracking-[3px] text-[11px] hover:bg-white/10 transition-all active:scale-95">
                Book Dining
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Feature Navigation */}
      <section className="max-w-7xl mx-auto px-6 pt-10 pb-32 grid grid-cols-1 md:grid-cols-3 gap-12 -mt-32 relative z-20">
        <FeatureCard 
          icon={<HotelIcon className="h-8 w-8 text-accent" />}
          title="Hotels"
          desc="Palaces, monoliths, and silent retreats."
          link="/hotels"
        />
        <FeatureCard 
          icon={<Utensils className="h-8 w-8 text-accent" />}
          title="Restaurants"
          desc="The finest culinary landmarks across India."
          link="/restaurants"
        />
        <FeatureCard 
          icon={<MapIcon className="h-8 w-8 text-accent" />}
          title="Explore"
          desc="Locate India's iconic heritage treasures."
          link="/explore"
        />
      </section>

      {/* Featured Teasers */}
      <section className="py-32 px-6 max-w-7xl mx-auto border-t border-white/5">
        <div className="flex justify-between items-end mb-20">
          <div>
            <span className="text-[10px] uppercase tracking-[4px] text-accent font-bold mb-4 block">Signature Collection</span>
            <h2 className="text-5xl font-serif italic text-text-bright">Elite Sanctuaries</h2>
          </div>
          {hotels.length === 0 && !loading && (
             <button onClick={seedData} className="text-[10px] uppercase tracking-[2px] font-bold text-text-dim hover:text-accent transition-all">Generate Archives</button>
          )}
        </div>

        {loading ? (
          <div className="flex justify-center items-center py-20">
            <Loader2 className="h-8 w-8 text-accent animate-spin" />
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12">
            {hotels.map((hotel) => (
              <TeaserCard key={hotel.id} hotel={hotel} />
            ))}
            {hotels.length === 0 && (
               <div className="col-span-full text-center py-20 bg-white/5 rounded-[3rem] border border-dashed border-white/10">
                 <p className="text-text-dim uppercase tracking-[3px] text-xs">No entries in the archive.</p>
               </div>
            )}
          </div>
        )}
      </section>
    </div>
  );
}

function FeatureCard({ icon, title, desc, link }: any) {
  return (
    <Link to={link} className="group relative bg-[#0a0a0a] p-10 rounded-[3rem] shadow-2xl border border-white/5 overflow-hidden h-96 flex flex-col justify-between hover:border-accent/40 transition-all duration-700">
      <div className="relative z-10">
        <div className="mb-8 opacity-60 group-hover:opacity-100 transition-opacity">{icon}</div>
        <h3 className="text-3xl font-serif italic text-text-bright mb-4">{title}</h3>
        <p className="text-text-dim text-sm leading-relaxed max-w-[200px]">{desc}</p>
      </div>
      <div className="relative z-10 flex items-center text-[10px] uppercase tracking-[4px] font-bold text-accent group-hover:translate-x-3 transition-transform duration-500">
        View Archive <ArrowRight className="h-4 w-4 ml-3" />
      </div>
      <div className="absolute top-0 right-0 p-12 text-white/5 font-serif italic text-8xl -mr-10 -mt-10 pointer-events-none group-hover:text-white/10 transition-colors">
         {title[0]}
      </div>
    </Link>
  );
}

function TeaserCard({ hotel }: { hotel: Hotel }) {
  return (
    <Link to="/hotels" className="block group">
      <div className="relative aspect-[4/5] rounded-[3rem] overflow-hidden mb-8 shadow-2xl border border-white/5 group-hover:border-accent/20 transition-all">
        <img src={hotel.image} className="w-full h-full object-cover grayscale brightness-75 group-hover:grayscale-0 group-hover:brightness-100 transition-all duration-1000 group-hover:scale-105" alt="" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#050505] via-[#050505]/20 to-transparent opacity-80" />
        <div className="absolute bottom-10 left-10 right-10 text-white">
          <div className="flex justify-between items-end mb-6">
            <div>
              <p className="text-[10px] uppercase tracking-[4px] text-accent font-bold mb-2">{hotel.city}</p>
              <h3 className="text-3xl font-serif italic text-text-bright">{hotel.name}</h3>
            </div>
            <div className="flex items-center space-x-2 px-4 py-2 bg-white/10 backdrop-blur-md rounded-full text-xs font-bold">
              <Star className="h-3.5 w-3.5 text-accent fill-current" />
              <span>{hotel.rating}</span>
            </div>
          </div>
          <div className="flex justify-between items-center pt-8 border-t border-white/10">
             <span className="text-xl font-serif text-accent">₹{hotel.price.toLocaleString()}</span>
             <span className="text-[10px] uppercase tracking-[3px] font-bold group-hover:text-accent transition-colors">Reserve Shrine</span>
          </div>
        </div>
      </div>
    </Link>
  );
}
