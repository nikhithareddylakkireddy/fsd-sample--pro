import React, { useEffect, useState } from 'react';
import { collection, query, getDocs, addDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Hotel } from '../types';
import { useAuth } from '../services/AuthContext';
import { sendBookingEmail } from '../services/emailService';
import { Search, MapPin, Star, Filter, Loader2, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { format, addDays } from 'date-fns';

export function Hotels() {
  const { user } = useAuth();
  const [hotels, setHotels] = useState<Hotel[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [cityFilter, setCityFilter] = useState('');
  const [priceRange, setPriceRange] = useState(50000);
  const [selectedHotel, setSelectedHotel] = useState<Hotel | null>(null);
  const [bookingLoading, setBookingLoading] = useState(false);

  useEffect(() => {
    async function fetchHotels() {
      try {
        const querySnapshot = await getDocs(collection(db, 'hotels'));
        const hotelList = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Hotel));
        setHotels(hotelList);
      } catch (error) {
        console.error('Error fetching hotels:', error);
      } finally {
        setLoading(false);
      }
    }
    fetchHotels();
  }, []);

  const filteredHotels = hotels.filter(h => 
    (h.name.toLowerCase().includes(searchTerm.toLowerCase()) || h.city.toLowerCase().includes(searchTerm.toLowerCase())) &&
    (cityFilter === '' || h.city === cityFilter) &&
    h.price <= priceRange
  );

  const cities = Array.from(new Set(hotels.map(h => h.city)));

  const handleBooking = async (hotel: Hotel) => {
    if (!user) {
      alert('Please sign in to book a hotel.');
      return;
    }

    setBookingLoading(true);
    const checkIn = format(addDays(new Date(), 1), 'yyyy-MM-dd');
    const checkOut = format(addDays(new Date(), 3), 'yyyy-MM-dd');
    const totalPrice = hotel.price * 2; // Assuming 2 nights

    try {
      const bookingData = {
        userId: user.uid,
        userEmail: user.email,
        hotelName: hotel.name,
        checkInDate: checkIn,
        checkOutDate: checkOut,
        guests: 2,
        totalPrice: totalPrice,
        status: 'Confirmed' as const,
        createdAt: new Date().toISOString()
      };

      const docRef = await addDoc(collection(db, 'bookings'), bookingData);
      console.log('Booking created', docRef.id);

      await sendBookingEmail({
        hotelName: hotel.name,
        checkInDate: checkIn,
        checkOutDate: checkOut,
        totalPrice: totalPrice,
        userEmail: user.email,
        status: 'Confirmed'
      });
      
      alert(`Booking confirmed at ${hotel.name}! An email has been sent to ${user.email}.`);
      setSelectedHotel(null);
    } catch (error) {
      console.error('Booking failed', error);
      alert('Booking failed. Please check console for details.');
    } finally {
      setBookingLoading(false);
    }
  };

  return (
    <div className="min-h-screen pt-24 pb-20 px-6 sm:px-10 lg:px-20 bg-[#f9f9f9]">
      <div className="max-w-7xl mx-auto">
        <header className="mb-12">
          <h1 className="text-4xl font-serif italic text-gray-900 mb-2">Find Your Perfect Stay</h1>
          <p className="text-gray-500">Curated hotels for your dream vacation across India.</p>
        </header>

        {/* Filters */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 flex flex-col md:flex-row gap-6 mb-12 items-end">
          <div className="flex-grow space-y-2">
            <label className="text-[10px] uppercase tracking-[2px] font-bold text-gray-400">Search</label>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
              <input 
                type="text" 
                placeholder="Hotel name or city" 
                className="w-full pl-10 pr-4 py-3 bg-gray-50 border border-gray-100 rounded-xl outline-none focus:border-blue-500 transition-all text-sm"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>

          <div className="w-full md:w-48 space-y-2">
            <label className="text-[10px] uppercase tracking-[2px] font-bold text-gray-400">City</label>
            <select 
              className="w-full px-4 py-3 bg-gray-50 border border-gray-100 rounded-xl outline-none focus:border-blue-500 transition-all text-sm appearance-none"
              value={cityFilter}
              onChange={(e) => setCityFilter(e.target.value)}
            >
              <option value="">All Cities</option>
              {cities.map(city => <option key={city} value={city}>{city}</option>)}
            </select>
          </div>

          <div className="w-full md:w-64 space-y-2">
            <div className="flex justify-between">
              <label className="text-[10px] uppercase tracking-[2px] font-bold text-gray-400">Max Price (₹)</label>
              <span className="text-xs font-bold text-blue-600">₹{priceRange.toLocaleString()}</span>
            </div>
            <input 
              type="range" 
              min="1000" 
              max="50000" 
              step="1000"
              className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
              value={priceRange}
              onChange={(e) => setPriceRange(parseInt(e.target.value))}
            />
          </div>
        </div>

        {loading ? (
          <div className="flex justify-center items-center py-40">
            <Loader2 className="h-10 w-10 text-blue-600 animate-spin" />
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
            {filteredHotels.map((hotel) => (
              <motion.div 
                key={hotel.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-white rounded-3xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 border border-gray-50 flex flex-col"
              >
                <div className="relative h-64 overflow-hidden">
                  <img src={hotel.image} className="w-full h-full object-cover" alt={hotel.name} />
                  <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm px-2 py-1 rounded-lg text-xs font-bold flex items-center space-x-1">
                    <Star className="h-3 w-3 text-yellow-500 fill-current" />
                    <span>{hotel.rating}</span>
                  </div>
                </div>
                <div className="p-6 flex-grow flex flex-col">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="text-xl font-bold text-gray-900">{hotel.name}</h3>
                    <p className="text-lg font-bold text-blue-600">₹{hotel.price.toLocaleString()}</p>
                  </div>
                  <div className="flex items-center text-gray-500 text-sm mb-4">
                    <MapPin className="h-3 w-3 mr-1" />
                    <span>{hotel.city}, {hotel.state}</span>
                  </div>
                  <div className="flex flex-wrap gap-2 mb-6">
                    {hotel.amenities.map(a => (
                      <span key={a} className="text-[10px] bg-gray-100 text-gray-600 px-2 py-1 rounded-md">{a}</span>
                    ))}
                  </div>
                  <button 
                    onClick={() => setSelectedHotel(hotel)}
                    className="mt-auto w-full py-3 bg-blue-600 text-white rounded-xl font-bold text-sm tracking-[1px] hover:bg-blue-700 transition-all active:scale-95"
                  >
                    View Details
                  </button>
                </div>
              </motion.div>
            ))}
          </div>
        )}

        {filteredHotels.length === 0 && !loading && (
          <div className="text-center py-40">
            <h3 className="text-xl font-medium text-gray-900">No hotels matching your search.</h3>
            <button onClick={() => { setSearchTerm(''); setCityFilter(''); setPriceRange(50000); }} className="text-blue-600 font-bold mt-4 hover:underline">Clear all filters</button>
          </div>
        )}
      </div>

      {/* Booking Modal */}
      <AnimatePresence>
        {selectedHotel && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedHotel(null)}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative w-full max-w-2xl bg-white rounded-[2.5rem] overflow-hidden shadow-2xl"
            >
              <div className="h-64 relative">
                <img src={selectedHotel.image} className="w-full h-full object-cover" alt="" />
                <button 
                  onClick={() => setSelectedHotel(null)}
                  className="absolute top-6 right-6 p-2 bg-white/20 backdrop-blur-md rounded-full text-white hover:bg-white/40 transition-all"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>
              <div className="p-8 md:p-12">
                <div className="flex justify-between items-start mb-6">
                  <div>
                    <h2 className="text-3xl font-serif italic text-gray-900 mb-1">{selectedHotel.name}</h2>
                    <p className="text-gray-500 font-medium">{selectedHotel.city}, {selectedHotel.state}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-2xl font-bold text-blue-600">₹{selectedHotel.price.toLocaleString()}</p>
                    <p className="text-xs text-gray-400 uppercase tracking-widest font-bold">per night</p>
                  </div>
                </div>

                <div className="space-y-6 mb-10">
                  <p className="text-gray-600 leading-relaxed">{selectedHotel.description}</p>
                  <div className="flex flex-wrap gap-3">
                    {selectedHotel.amenities.map(a => (
                      <div key={a} className="px-4 py-2 bg-gray-50 border border-gray-100 rounded-xl text-xs font-bold text-gray-700 tracking-wide uppercase">{a}</div>
                    ))}
                  </div>
                </div>

                <div className="flex gap-4">
                  <button 
                    disabled={bookingLoading}
                    onClick={() => handleBooking(selectedHotel)}
                    className="flex-grow py-5 bg-blue-600 text-white font-bold rounded-2xl hover:bg-blue-700 transition-all active:scale-95 disabled:opacity-50 flex items-center justify-center space-x-3 shadow-lg shadow-blue-500/20"
                  >
                    {bookingLoading ? <Loader2 className="h-5 w-5 animate-spin" /> : <span>Confirm Reservation</span>}
                  </button>
                  <button 
                    onClick={() => setSelectedHotel(null)}
                    className="px-8 py-5 border border-gray-200 text-gray-500 font-bold rounded-2xl hover:bg-gray-50 transition-all"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
