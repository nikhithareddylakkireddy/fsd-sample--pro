import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

interface Hotel {
  id: string;
  name: string;
  city?: string;
  location?: string;
  price: number;
  image?: string;
}

export function Home() {
  const [hotels, setHotels] = useState<Hotel[]>([]);
  const [loading, setLoading] = useState(true);
  const user = JSON.parse(localStorage.getItem('user') || 'null');
  const navigate = useNavigate();

  useEffect(() => {
    fetch('/api/hotels')
      .then(res => res.json())
      .then(data => {
        setHotels(data);
        setLoading(false);
      });
  }, []);

  const bookHotel = async (hotel: Hotel) => {
    const token = localStorage.getItem('token');
    if (!token) {
      alert("Please login first");
      navigate('/login');
      return;
    }

    try {
      const res = await fetch('/api/bookings', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          hotelId: hotel.id,
          hotelName: hotel.name,
          hotelLocation: hotel.city || hotel.location || 'N/A',
          price: hotel.price,
          date: new Date().toLocaleDateString()
        })
      });

      if (!res.ok) throw new Error("Booking failed");
      alert("Hotel booked successfully!");
      navigate('/bookings');
    } catch (err: any) {
      alert(err.message);
    }
  };

  const handleLogout = () => {
    localStorage.clear();
    window.location.reload();
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-12">
      <div className="flex justify-between items-center mb-12">
        <h1 className="text-4xl font-bold">StayFlow Hotels</h1>
        {user ? (
          <div className="flex items-center space-x-6">
            <span className="text-gray-600">Welcome, <strong>{user.name}</strong></span>
            <button onClick={() => navigate('/bookings')} className="text-blue-600 font-bold hover:underline">My Bookings</button>
            <button onClick={handleLogout} className="px-4 py-2 bg-gray-200 rounded-lg hover:bg-gray-300">Logout</button>
          </div>
        ) : (
          <div className="flex space-x-4">
            <button onClick={() => navigate('/login')} className="px-6 py-2 bg-blue-600 text-white rounded-lg">Login</button>
            <button onClick={() => navigate('/register')} className="px-6 py-2 border border-blue-600 text-blue-600 rounded-lg">Register</button>
          </div>
        )}
      </div>

      {loading ? (
        <div className="text-center py-20 text-gray-400">Loading hotels...</div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {hotels.map((hotel) => (
            <div key={hotel.id} className="bg-white border border-gray-200 rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-shadow">
              <div className="h-48 bg-gray-100">
                <img src={hotel.image || 'https://images.unsplash.com/photo-1566073771259-6a8506099945?w=500'} className="w-full h-full object-cover" alt="" />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold mb-2">{hotel.name}</h3>
                <p className="text-gray-500 mb-4">{hotel.city || hotel.location || 'Various Locations'}</p>
                <div className="flex justify-between items-center">
                  <span className="text-2xl font-bold text-blue-600">₹{hotel.price.toLocaleString()}</span>
                  <button onClick={() => bookHotel(hotel)} className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">Book Now</button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
