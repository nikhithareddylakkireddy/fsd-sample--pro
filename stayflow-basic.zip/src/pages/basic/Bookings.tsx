import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

interface Booking {
  id: string;
  hotelName: string;
  hotelLocation: string;
  price: number;
  date: string;
}

export function Bookings() {
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (!token) {
      navigate('/login');
      return;
    }

    fetch('/api/my-bookings', {
      headers: { 'Authorization': `Bearer ${token}` }
    })
      .then(res => res.json())
      .then(data => {
        setBookings(data);
        setLoading(false);
      })
      .catch(err => {
        console.error(err);
        setLoading(false);
      });
  }, [navigate]);

  return (
    <div className="max-w-6xl mx-auto px-4 py-12">
      <div className="flex items-center space-x-4 mb-12">
        <button onClick={() => navigate('/')} className="p-2 hover:bg-gray-100 rounded-lg">← Back</button>
        <h1 className="text-4xl font-bold">My Bookings</h1>
      </div>

      {loading ? (
        <div className="text-center py-20 text-gray-400">Loading your bookings...</div>
      ) : bookings.length === 0 ? (
        <div className="text-center py-20 bg-gray-50 rounded-xl">
          <p className="text-gray-500 mb-6">You haven't booked any hotels yet.</p>
          <button onClick={() => navigate('/')} className="px-8 py-3 bg-blue-600 text-white rounded-lg">Browse Hotels</button>
        </div>
      ) : (
        <div className="bg-white border border-gray-200 rounded-xl overflow-hidden shadow-sm">
          <table className="w-full text-left">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-6 py-4 text-sm font-bold uppercase tracking-wider text-gray-500">Hotel</th>
                <th className="px-6 py-4 text-sm font-bold uppercase tracking-wider text-gray-500">Location</th>
                <th className="px-6 py-4 text-sm font-bold uppercase tracking-wider text-gray-500">Booked On</th>
                <th className="px-6 py-4 text-sm font-bold uppercase tracking-wider text-gray-500">Price</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {bookings.map((booking) => (
                <tr key={booking.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-6 py-4 font-bold text-gray-900">{booking.hotelName}</td>
                  <td className="px-6 py-4 text-gray-600">{booking.hotelLocation}</td>
                  <td className="px-6 py-4 text-gray-500">{booking.date}</td>
                  <td className="px-6 py-4 font-bold text-blue-600">₹{booking.price.toLocaleString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
