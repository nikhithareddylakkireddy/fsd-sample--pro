import React, { useEffect, useState } from 'react';
import { collection, query, getDocs } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Restaurant } from '../types';
import { Search, MapPin, Star, Utensils, Loader2 } from 'lucide-react';
import { motion } from 'motion/react';

export function Restaurants() {
  const [restaurants, setRestaurants] = useState<Restaurant[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    async function fetchRestaurants() {
      try {
        const querySnapshot = await getDocs(collection(db, 'restaurants'));
        const restList = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Restaurant));
        setRestaurants(restList);
      } catch (error) {
        console.error('Error fetching restaurants:', error);
      } finally {
        setLoading(false);
      }
    }
    fetchRestaurants();
  }, []);

  const filteredRestaurants = restaurants.filter(r => 
    r.name.toLowerCase().includes(searchTerm.toLowerCase()) || r.city.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen pt-24 pb-20 px-6 sm:px-10 lg:px-20 bg-[#fefefe]">
      <div className="max-w-7xl mx-auto">
        <header className="mb-12">
          <h1 className="text-4xl font-serif italic text-gray-900 mb-2">Exquisite Dining</h1>
          <p className="text-gray-500">Discover the best culinary experiences around you.</p>
        </header>

        <div className="mb-12 relative max-w-xl">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
          <input 
            type="text" 
            placeholder="Search by restaurant or city..." 
            className="w-full pl-12 pr-4 py-4 rounded-2xl bg-gray-50 border-none shadow-sm focus:ring-2 focus:ring-blue-500 outline-none text-gray-900 transition-all font-medium"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>

        {loading ? (
          <div className="flex justify-center items-center py-40">
            <Loader2 className="h-10 w-10 text-blue-600 animate-spin" />
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
            {filteredRestaurants.map((rest, idx) => (
              <motion.div 
                key={rest.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.1 }}
                className="group relative bg-white rounded-[2rem] overflow-hidden border border-gray-100 shadow-sm hover:shadow-2xl transition-all duration-500"
              >
                <div className="h-64 overflow-hidden relative">
                  <img src={rest.image} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" alt={rest.name} />
                  <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm px-3 py-1 rounded-full text-xs font-bold text-gray-900 flex items-center space-x-1 shadow-sm">
                    <Star className="h-3.5 w-3.5 text-yellow-500 fill-current" />
                    <span>{rest.rating}</span>
                  </div>
                </div>
                <div className="p-8">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="text-2xl font-serif italic text-gray-900">{rest.name}</h3>
                    <div className="text-right">
                      <p className="text-blue-600 font-bold text-sm">₹{rest.costForTwo}</p>
                      <p className="text-[10px] uppercase font-bold text-gray-400">for two</p>
                    </div>
                  </div>
                  <div className="flex items-center text-gray-500 text-sm mb-6">
                    <MapPin className="h-4 w-4 mr-1 text-red-400" />
                    <span>{rest.city}</span>
                    <span className="mx-2">•</span>
                    <Utensils className="h-4 w-4 mr-1 text-orange-400" />
                    <span>{rest.cuisine}</span>
                  </div>
                  
                  <button 
                    onClick={() => alert(`Table booking functionality for ${rest.name} is being prepared!`)}
                    className="w-full py-4 bg-gray-900 text-white rounded-2xl font-bold text-xs uppercase tracking-[2px] transition-all hover:bg-blue-600 active:scale-95 shadow-sm"
                  >
                    Reserve a Table
                  </button>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
