import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { doc, getDoc, collection, addDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Property, Booking } from '../types';
import { useAuth } from '../services/AuthContext';
import { Star, MapPin, Calendar, Users, Shield, Check, ArrowLeft, Loader2 } from 'lucide-react';
import { motion } from 'motion/react';
import { format, addDays, differenceInDays } from 'date-fns';
import { cn } from '../lib/utils';

export function PropertyDetails() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { user, signInWithGoogle } = useAuth();
  
  const [property, setProperty] = useState<Property | null>(null);
  const [loading, setLoading] = useState(true);
  const [bookingLoading, setBookingLoading] = useState(false);
  
  const [checkIn, setCheckIn] = useState(format(addDays(new Date(), 1), 'yyyy-MM-dd'));
  const [checkOut, setCheckOut] = useState(format(addDays(new Date(), 3), 'yyyy-MM-dd'));

  useEffect(() => {
    async function fetchProperty() {
      if (!id) return;
      try {
        const snap = await getDoc(doc(db, 'properties', id));
        if (snap.exists()) {
          setProperty({ id: snap.id, ...snap.data() } as Property);
        }
      } catch (error) {
        console.error('Error fetching property:', error);
      } finally {
        setLoading(false);
      }
    }
    fetchProperty();
  }, [id]);

  const numDays = differenceInDays(new Date(checkOut), new Date(checkIn));
  const totalPrice = property ? numDays * property.pricePerNight : 0;

  const handleBooking = async () => {
    if (!user) {
      await signInWithGoogle();
      return;
    }

    if (!property || !id || numDays <= 0) return;

    setBookingLoading(true);
    try {
      const bookingData = {
        propertyId: id,
        userId: user.uid,
        checkIn,
        checkOut,
        totalPrice,
        status: 'pending' as const,
        createdAt: new Date().toISOString()
      };
      
      await addDoc(collection(db, 'bookings'), bookingData);
      navigate('/my-bookings');
    } catch (error) {
      console.error('Booking failed:', error);
      alert('Booking failed. Please try again.');
    } finally {
      setBookingLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-bg">
        <Loader2 className="h-8 w-8 text-accent animate-spin" />
      </div>
    );
  }

  if (!property) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center px-4 bg-bg">
        <h2 className="text-2xl font-serif italic text-text-bright mb-4">Sanctuary not found</h2>
        <button onClick={() => navigate('/')} className="text-accent underline underline-offset-4 uppercase tracking-[2px] text-xs">Back to Archives</button>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col lg:flex-row bg-bg">
      {/* Visual Pane (Left) */}
      <section className="relative w-full lg:w-3/5 xl:w-2/3 h-[50vh] lg:h-screen bg-black overflow-hidden flex items-end p-8 lg:p-20">
        <div className="absolute inset-0 z-0">
          <img 
            src={property.images[0]} 
            className="w-full h-full object-cover opacity-70 grayscale lg:opacity-60" 
            alt={property.name} 
          />
          <div className="absolute inset-0 bg-gradient-to-t from-bg via-transparent to-bg/20" />
          <div className="absolute top-[10%] left-[10%] w-[60%] h-[60%] bg-radial from-accent/5 via-transparent to-transparent blur-[120px] pointer-events-none" />
        </div>

        <div className="relative z-10 max-w-2xl">
          <button 
            onClick={() => navigate('/')} 
            className="inline-flex items-center text-[10px] uppercase font-bold tracking-[3px] text-accent hover:text-white transition-colors mb-8"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Collection
          </button>
          
          <div className="text-[11px] uppercase tracking-[4px] text-accent font-semibold mb-4">Exclusive Stay</div>
          <h1 className="text-5xl lg:text-7xl font-serif italic text-text-bright mb-8 leading-tight tracking-tight">
            {property.name}
          </h1>
          
          <div className="flex items-center space-x-6 text-xs uppercase tracking-[2px] text-text-dim">
            <div className="flex items-center">
              <MapPin className="h-3 w-3 mr-2 text-accent" />
              {property.city}
            </div>
            <div className="flex items-center">
              <Star className="h-3 w-3 mr-2 text-accent fill-current" />
              {property.rating} / 5.0
            </div>
          </div>
        </div>
      </section>

      {/* Control Pane (Right) */}
      <section className="w-full lg:w-2/5 xl:w-1/3 bg-[#080808] border-l border-white/5 p-8 lg:p-16 flex flex-col justify-between pt-28">
        <div className="booking-card">
          <div className="price-display mb-12 flex items-baseline gap-2">
            <span className="text-4xl font-serif text-text-bright">${property.pricePerNight}</span>
            <span className="text-xs uppercase tracking-[2px] text-text-dim">/ per night</span>
          </div>

          <div className="space-y-10">
            <div className="input-group">
              <div className="text-[10px] uppercase tracking-[2px] text-text-dim mb-3">Accommodation</div>
              <div className="w-full p-5 bg-white/5 border border-white/10 text-xs font-medium tracking-[1px] text-white">
                {property.name}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-6">
              <div className="input-group">
                <div className="text-[10px] uppercase tracking-[2px] text-text-dim mb-3">Check In</div>
                <input 
                  type="date"
                  className="w-full p-5 bg-color-glass border border-white/10 rounded-none outline-none text-xs font-medium text-white focus:border-accent invert"
                  value={checkIn}
                  onChange={(e) => setCheckIn(e.target.value)}
                />
              </div>
              <div className="input-group">
                <div className="text-[10px] uppercase tracking-[2px] text-text-dim mb-3">Guests</div>
                <select className="w-full p-5 bg-color-glass border border-white/10 rounded-none outline-none text-xs font-medium text-white appearance-none focus:border-accent">
                  <option className="bg-bg">02 Guests</option>
                  <option className="bg-bg">01 Guest</option>
                  <option className="bg-bg">03 Guests</option>
                </select>
              </div>
            </div>

            <button 
              disabled={bookingLoading || numDays <= 0}
              onClick={handleBooking}
              className="w-full bg-accent hover:bg-white text-black font-bold text-[11px] uppercase tracking-[4px] py-6 rounded-none shadow-2xl transition-all active:scale-95 disabled:opacity-30 disabled:grayscale"
            >
              {bookingLoading ? <Loader2 className="h-5 w-5 animate-spin mx-auto" /> : user ? 'Request Reservation' : 'Sign in to Reserve'}
            </button>
          </div>

          <div className="grid grid-cols-2 gap-8 mt-16 pt-10 border-t border-white/5">
            <div className="meta-item">
              <div className="text-[10px] uppercase tracking-[2px] text-text-dim mb-3">Experience</div>
              <p className="text-[11px] leading-relaxed text-text-dim italic">
                Bespoke guidance, private lounge, and curated local insights.
              </p>
            </div>
            <div className="meta-item">
              <div className="text-[10px] uppercase tracking-[2px] text-text-dim mb-3">Details</div>
              <p className="text-[11px] leading-relaxed text-text-dim italic">
                Minimum 3-night stay required for priority service.
              </p>
            </div>
          </div>
        </div>

        <div className="mt-16 text-[11px] uppercase tracking-[3px] text-text-dim/50 flex items-center">
           <Shield className="h-3 w-3 mr-2" />
           Verified by StayFlow. Secure Booking.
        </div>
      </section>
    </div>
  );
}
