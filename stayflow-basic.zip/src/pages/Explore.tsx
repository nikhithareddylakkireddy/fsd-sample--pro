import React, { useState } from 'react';
import { GoogleMap, useJsApiLoader, Marker, InfoWindow } from '@react-google-maps/api';
import { Search, Map as MapIcon, Navigation, Loader2 } from 'lucide-react';
import { motion } from 'motion/react';

const containerStyle = {
  width: '100%',
  height: '70vh'
};

const center = {
  lat: 28.6139,
  lng: 77.2090 // New Delhi
};

const PLACES = [
  { id: 1, name: "Taj Mahal", city: "Agra", lat: 27.1751, lng: 78.0421, description: "World-renowned marble mausoleum.", distance: "230 km from Delhi" },
  { id: 2, name: "Qutub Minar", city: "Delhi", lat: 28.5245, lng: 77.1855, description: "UNESCO World Heritage site.", distance: "Local" },
  { id: 3, name: "Amber Fort", city: "Jaipur", lat: 26.9855, lng: 75.8513, description: "Magnificent hill fort.", distance: "280 km from Delhi" },
  { id: 4, name: "Gateway of India", city: "Mumbai", lat: 18.9220, lng: 72.8347, description: "Iconic arch monument.", distance: "Long distance" },
];

export function Explore() {
  const { isLoaded } = useJsApiLoader({
    id: 'google-map-script',
    googleMapsApiKey: import.meta.env.VITE_GOOGLE_MAPS_API_KEY || ''
  });

  const [selectedPlace, setSelectedPlace] = useState<typeof PLACES[0] | null>(null);
  const [map, setMap] = React.useState(null);

  const onLoad = React.useCallback(function callback(map: any) {
    const bounds = new window.google.maps.LatLngBounds(center);
    map.fitBounds(bounds);
    setMap(map);
  }, []);

  const onUnmount = React.useCallback(function callback(map: any) {
    setMap(null);
  }, []);

  return (
    <div className="min-h-screen pt-24 pb-20 bg-[#f8f9fa]">
      <div className="max-w-7xl mx-auto px-6 sm:px-10">
        <header className="mb-10 text-center md:text-left flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div>
            <h1 className="text-4xl font-serif italic text-gray-900 mb-2">Explore Destinations</h1>
            <p className="text-gray-500">Locate the most iconic travel spots and plan your visit.</p>
          </div>
          <div className="flex gap-4">
             <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                <input 
                  type="text" 
                  placeholder="Find a city..." 
                  className="pl-10 pr-4 py-3 bg-white border border-gray-100 rounded-xl outline-none shadow-sm text-sm"
                />
             </div>
             <button className="px-6 py-3 bg-gray-900 text-white rounded-xl font-bold text-xs uppercase tracking-widest shadow-lg">Search</button>
          </div>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 rounded-[2.5rem] overflow-hidden shadow-2xl border-8 border-white">
            {isLoaded ? (
              <GoogleMap
                mapContainerStyle={containerStyle}
                center={center}
                zoom={5}
                onLoad={onLoad}
                onUnmount={onUnmount}
                options={{
                  styles: mapStyles,
                  disableDefaultUI: true,
                  zoomControl: true,
                }}
              >
                {PLACES.map(place => (
                  <Marker 
                    key={place.id} 
                    position={{ lat: place.lat, lng: place.lng }} 
                    onClick={() => setSelectedPlace(place)}
                  />
                ))}

                {selectedPlace && (
                  <InfoWindow 
                    position={{ lat: selectedPlace.lat, lng: selectedPlace.lng }}
                    onCloseClick={() => setSelectedPlace(null)}
                  >
                    <div className="p-2 max-w-xs">
                      <h4 className="font-bold text-gray-900">{selectedPlace.name}</h4>
                      <p className="text-xs text-gray-500 mb-1">{selectedPlace.city}</p>
                      <p className="text-xs text-gray-600">{selectedPlace.description}</p>
                      <div className="mt-2 text-[10px] uppercase font-bold text-blue-600 tracking-wider">
                        {selectedPlace.distance}
                      </div>
                    </div>
                  </InfoWindow>
                )}
              </GoogleMap>
            ) : (
              <div className="h-[70vh] w-full bg-gray-100 flex items-center justify-center">
                {!import.meta.env.VITE_GOOGLE_MAPS_API_KEY ? (
                  <div className="text-center p-8">
                    <MapIcon className="h-12 w-12 text-gray-300 mx-auto mb-4" />
                    <p className="text-gray-500 font-medium">Please provide a Google Maps API Key in environment variables.</p>
                  </div>
                ) : (
                  <Loader2 className="h-10 w-10 text-gray-300 animate-spin" />
                )}
              </div>
            )}
          </div>

          <div className="space-y-6">
            <h3 className="text-[11px] uppercase tracking-[4px] font-bold text-gray-400 mb-4 px-2">Featured Heritage</h3>
            {PLACES.map((place) => (
              <motion.div 
                key={place.id}
                whileHover={{ scale: 1.02 }}
                onClick={() => setSelectedPlace(place)}
                className={`p-6 rounded-3xl border transition-all cursor-pointer ${selectedPlace?.id === place.id ? 'bg-white border-blue-200 shadow-xl' : 'bg-white/50 border-gray-100 hover:border-blue-100'}`}
              >
                <div className="flex items-start justify-between mb-2">
                   <div>
                     <h4 className="text-lg font-serif italic text-gray-900">{place.name}</h4>
                     <p className="text-sm text-gray-500">{place.city}</p>
                   </div>
                   <Navigation className="h-4 w-4 text-gray-300" />
                </div>
                <p className="text-xs text-gray-600 leading-relaxed line-clamp-2">{place.description}</p>
                <div className="mt-4 flex items-center justify-between">
                  <span className="text-[10px] font-bold text-blue-600 px-2 py-1 bg-blue-50 rounded-lg uppercase tracking-wider">{place.distance}</span>
                  <button className="text-[10px] font-bold text-gray-400 uppercase tracking-widest hover:text-blue-600">Directions</button>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

const mapStyles = [
  {
    "featureType": "administrative",
    "elementType": "labels.text.fill",
    "stylers": [{ "color": "#444444" }]
  },
  {
    "featureType": "landscape",
    "elementType": "all",
    "stylers": [{ "color": "#f2f2f2" }]
  },
  {
    "featureType": "poi",
    "elementType": "all",
    "stylers": [{ "visibility": "off" }]
  },
  {
    "featureType": "road",
    "elementType": "all",
    "stylers": [{ "saturation": -100 }, { "lightness": 45 }]
  },
  {
    "featureType": "water",
    "elementType": "all",
    "stylers": [{ "color": "#dadaf5" }, { "visibility": "on" }]
  }
];
