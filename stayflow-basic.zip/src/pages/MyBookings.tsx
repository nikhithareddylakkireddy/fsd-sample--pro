import React, { useEffect, useState } from 'react';
import { collection, query, where, getDocs, doc, updateDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Booking, Property } from '../types';
import { useAuth } from '../services/AuthContext';
import { sendBookingEmail } from '../services/emailService';
import { Calendar, MapPin, Clock, CheckCircle2, XCircle, AlertCircle, Loader2, Users, Hotel } from 'lucide-react';
import { format } from 'date-fns';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../lib/utils';

interface BookingWithProperty extends Booking {
  property?: Property;
}

export function MyBookings() {
  const { user, loading: authLoading } = useAuth();
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState<'All' | 'Confirmed' | 'Cancelled'>('All');

  useEffect(() => {
    async function fetchBookings() {
      if (!user) return;
      
      try {
        const q = query(
          collection(db, 'bookings'),
          where('userId', '==', user.uid)
        );
        const querySnapshot = await getDocs(q);
        const bookingList = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Booking));
        setBookings(bookingList.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()));
      } catch (error) {
        console.error('Error fetching bookings:', error);
      } finally {
        setLoading(false);
      }
    }

    if (!authLoading && user) {
      fetchBookings();
    } else if (!authLoading && !user) {
      setLoading(false);
    }
  }, [user, authLoading]);

  const cancelBooking = async (booking: Booking) => {
    if (!confirm('Are you sure you want to cancel this booking?')) return;
    
    try {
      await updateDoc(doc(db, 'bookings', booking.id), { status: 'Cancelled' });
      setBookings(prev => prev.map(b => b.id === booking.id ? { ...b, status: 'Cancelled' } : b));
      
      console.log('Booking cancelled', booking.id);
      
      await sendBookingEmail({
        hotelName: booking.hotelName,
        checkInDate: booking.checkInDate,
        checkOutDate: booking.checkOutDate,
        totalPrice: booking.totalPrice,
        userEmail: booking.userEmail,
        status: 'Cancelled',
        message: `Your booking at ${booking.hotelName} for ${booking.checkInDate} to ${booking.checkOutDate} has been cancelled.`
      });
      
      alert('Booking cancelled. A notification email has been sent.');
    } catch (error) {
      console.error('Error cancelling booking:', error);
      alert('Cancellation failed.');
    }
  };

  const filteredBookings = bookings.filter(b => statusFilter === 'All' || b.status === statusFilter);

  if (authLoading || loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#f9f9f9]">
        <Loader2 className="h-8 w-8 text-blue-600 animate-spin" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center px-4 bg-[#f9f9f9]">
        <div className="p-12 bg-white rounded-[3rem] shadow-xl border border-gray-100 text-center max-w-lg">
          <h2 className="text-3xl font-serif italic text-gray-900 mb-4">Secure Access Required</h2>
          <p className="text-gray-500 mb-8 leading-relaxed">Please sign in to view your archives, manage reservations, and track your travels.</p>
          <div className="flex justify-center flex-wrap gap-4">
             <button className="px-10 py-4 bg-blue-600 text-white rounded-2xl font-bold text-sm tracking-widest hover:bg-blue-700 transition-all shadow-lg shadow-blue-500/20">Sign In Now</button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto px-6 py-32 animate-in fade-in duration-700 min-h-screen">
      <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-8">
        <div>
          <div className="text-[11px] uppercase tracking-[4px] text-blue-600 font-bold mb-4">Personal Dashboard</div>
          <h1 className="text-4xl lg:text-5xl font-serif italic text-gray-900">Your Journey Archives</h1>
        </div>
        
        <div className="flex bg-gray-100 p-1 rounded-2xl">
          {['All', 'Confirmed', 'Cancelled'].map((status) => (
            <button
              key={status}
              onClick={() => setStatusFilter(status as any)}
              className={cn(
                "px-6 py-2 rounded-xl text-xs font-bold uppercase tracking-wider transition-all",
                statusFilter === status ? "bg-white text-blue-600 shadow-sm" : "text-gray-500 hover:text-gray-900"
              )}
            >
              {status}
            </button>
          ))}
        </div>
      </div>

      {filteredBookings.length > 0 ? (
        <div className="grid grid-cols-1 gap-8">
          {filteredBookings.map((booking, idx) => (
            <motion.div 
              key={booking.id}
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: idx * 0.1 }}
              className="bg-white rounded-[2.5rem] p-8 md:p-10 border border-gray-100 shadow-sm hover:shadow-xl transition-all duration-500 flex flex-col md:flex-row gap-10"
            >
              <div className="flex-grow">
                <div className="flex justify-between items-start mb-8">
                  <div>
                    <h3 className="text-2xl font-serif italic text-gray-900 mb-2">{booking.hotelName}</h3>
                    <div className={cn(
                      "inline-flex items-center space-x-2 px-3 py-1 rounded-lg text-[10px] font-bold uppercase tracking-[2px]",
                      booking.status === 'Confirmed' ? "bg-green-50 text-green-600" : "bg-red-50 text-red-600"
                    )}>
                      <span className={cn("w-1.5 h-1.5 rounded-full", booking.status === 'Confirmed' ? "bg-green-500" : "bg-red-500")}></span>
                      <span>{booking.status}</span>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-xs text-gray-400 uppercase tracking-widest font-bold mb-1">Total Assets Locked</p>
                    <p className="text-2xl font-bold text-gray-900">₹{booking.totalPrice.toLocaleString()}</p>
                  </div>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-10 pb-10 border-b border-gray-50">
                  <div>
                    <div className="text-[9px] uppercase tracking-[2px] text-gray-400 mb-2 font-bold flex items-center"><Calendar className="h-3 w-3 mr-1" /> Check In</div>
                    <div className="text-sm text-gray-900 font-serif italic">{format(new Date(booking.checkInDate), 'MMM d, yyyy')}</div>
                  </div>
                  <div>
                    <div className="text-[9px] uppercase tracking-[2px] text-gray-400 mb-2 font-bold flex items-center"><Calendar className="h-3 w-3 mr-1" /> Check Out</div>
                    <div className="text-sm text-gray-900 font-serif italic">{format(new Date(booking.checkOutDate), 'MMM d, yyyy')}</div>
                  </div>
                  <div>
                    <div className="text-[9px] uppercase tracking-[2px] text-gray-400 mb-2 font-bold flex items-center"><Users className="h-3 w-3 mr-1" /> Guests</div>
                    <div className="text-sm text-gray-900 font-bold">{booking.guests} People</div>
                  </div>
                  <div>
                    <div className="text-[9px] uppercase tracking-[2px] text-gray-400 mb-2 font-bold">Created At</div>
                    <div className="text-sm text-gray-400">{format(new Date(booking.createdAt), 'MMM d, HH:mm')}</div>
                  </div>
                </div>

                <div className="flex justify-end">
                  {booking.status === 'Confirmed' && (
                    <button 
                      onClick={() => cancelBooking(booking)}
                      className="px-8 py-3 border border-gray-100 text-red-500 hover:bg-red-50 hover:border-red-100 rounded-xl font-bold text-[10px] uppercase tracking-[2px] transition-all"
                    >
                      Cancel Reservation
                    </button>
                  )}
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      ) : (
        <div className="text-center py-40 bg-white rounded-[3rem] border border-gray-100 shadow-sm px-8">
          <div className="w-20 h-20 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-8">
            <Hotel className="h-8 w-8 text-gray-300" />
          </div>
          <h3 className="text-xl font-serif italic text-gray-900 mb-3">No archives found for this filter</h3>
          <p className="text-gray-500 mb-10 max-w-sm mx-auto">Your future adventures await. Begin your exploration to add to your archives.</p>
          <a href="/hotels" className="inline-block px-12 py-5 bg-blue-600 text-white rounded-2xl font-bold text-[11px] uppercase tracking-[3px] hover:bg-blue-700 transition-all shadow-xl shadow-blue-500/20">
            Find Sanctuary
          </a>
        </div>
      )}
    </div>
  );
}

