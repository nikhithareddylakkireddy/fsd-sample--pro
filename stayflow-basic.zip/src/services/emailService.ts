import emailjs from '@emailjs/browser';

const SERVICE_ID = import.meta.env.VITE_EMAILJS_SERVICE_ID;
const TEMPLATE_ID = import.meta.env.VITE_EMAILJS_TEMPLATE_ID;
const PUBLIC_KEY = import.meta.env.VITE_EMAILJS_PUBLIC_KEY;

export interface EmailParams {
  hotelName: string;
  checkInDate: string;
  checkOutDate: string;
  totalPrice: number;
  userEmail: string;
  status: string;
  message?: string;
}

export const sendBookingEmail = async (params: EmailParams) => {
  if (!SERVICE_ID || !TEMPLATE_ID || !PUBLIC_KEY) {
    console.warn('EmailJS not properly configured. Check environment variables.');
    return;
  }

  try {
    const response = await emailjs.send(
      SERVICE_ID,
      TEMPLATE_ID,
      {
        subject: params.status === 'Confirmed' ? 'Booking Confirmed ✅' : 'Booking Cancelled ❌',
        hotel_name: params.hotelName,
        check_in: params.checkInDate,
        check_out: params.checkOutDate,
        total_price: params.totalPrice,
        user_email: params.userEmail,
        status: params.status,
        message: params.message || `Your booking at ${params.hotelName} has been ${params.status.toLowerCase()}.`
      },
      PUBLIC_KEY
    );
    console.log('Email sent successfully', response.status, response.text);
  } catch (error) {
    console.error('Email failed to send', error);
  }
};
