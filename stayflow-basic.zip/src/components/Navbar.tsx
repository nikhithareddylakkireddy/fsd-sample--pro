import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../services/AuthContext';
import { Hotel, User, LogOut, Menu, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../lib/utils';

export function Navbar() {
  const { user, signInWithGoogle, logout } = useAuth();
  const [isOpen, setIsOpen] = React.useState(false);

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-[#050505]/80 backdrop-blur-md border-b border-white/10">
      <div className="max-w-7xl mx-auto px-6 sm:px-10 lg:px-12">
        <div className="flex justify-between h-20 items-center">
          <Link to="/" className="flex items-center space-x-2 group">
            <span className="text-2xl font-serif italic text-text-bright tracking-tight">StayFlow.</span>
          </Link>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center space-x-10">
            <Link to="/hotels" className="text-[11px] uppercase tracking-[3px] font-medium text-text-dim hover:text-white transition-colors">Hotels</Link>
            <Link to="/restaurants" className="text-[11px] uppercase tracking-[3px] font-medium text-text-dim hover:text-white transition-colors">Restaurants</Link>
            <Link to="/explore" className="text-[11px] uppercase tracking-[3px] font-medium text-text-dim hover:text-white transition-colors">Explore</Link>
            
            {user && (
              <Link to="/bookings" className="text-[11px] uppercase tracking-[3px] font-medium text-text-dim hover:text-white transition-colors">Dashboard</Link>
            )}
            
            {user ? (
              <div className="flex items-center space-x-6">
                <div className="flex items-center space-x-3">
                  <img src={user.photoURL || `https://ui-avatars.com/api/?name=${user.displayName}`} className="h-7 w-7 rounded-full grayscale border border-white/10" alt="" />
                  <span className="text-[11px] uppercase tracking-[2px] text-text-bright">{user.displayName}</span>
                </div>
                <button onClick={() => logout()} className="p-2 text-text-dim hover:text-accent transition-colors" title="Logout">
                  <LogOut className="h-4 w-4" />
                </button>
              </div>
            ) : (
              <button 
                onClick={() => signInWithGoogle()}
                className="text-[11px] uppercase tracking-[3px] font-bold text-accent hover:text-white transition-all underline underline-offset-8"
              >
                Sign In
              </button>
            )}
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden flex items-center">
            <button onClick={() => setIsOpen(!isOpen)} className="text-text-bright">
              {isOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Nav */}
      <AnimatePresence>
        {isOpen && (
          <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-[#080808] border-b border-white/10 overflow-hidden"
          >
            <div className="px-6 pt-4 pb-8 space-y-4">
              <Link to="/hotels" onClick={() => setIsOpen(false)} className="block text-[11px] uppercase tracking-[3px] text-text-dim hover:text-white">Hotels</Link>
              <Link to="/restaurants" onClick={() => setIsOpen(false)} className="block text-[11px] uppercase tracking-[3px] text-text-dim hover:text-white">Restaurants</Link>
              <Link to="/explore" onClick={() => setIsOpen(false)} className="block text-[11px] uppercase tracking-[3px] text-text-dim hover:text-white">Explore</Link>
              {user && (
                <Link to="/bookings" onClick={() => setIsOpen(false)} className="block text-[11px] uppercase tracking-[3px] text-text-dim hover:text-white">Dashboard</Link>
              )}
              {user ? (
                <button onClick={() => { logout(); setIsOpen(false); }} className="w-full text-left text-[11px] uppercase tracking-[3px] text-accent">Log Out</button>
              ) : (
                <button onClick={() => { signInWithGoogle(); setIsOpen(false); }} className="w-full text-left text-[11px] uppercase tracking-[3px] text-accent">Sign In</button>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}
