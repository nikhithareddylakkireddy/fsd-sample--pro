import React from 'react';
import { Hotel, Facebook, Twitter, Instagram } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-[#050505] border-t border-white/5 py-24 px-6 sm:px-10 lg:px-12">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-16">
        <div className="col-span-1 md:col-span-2">
          <div className="flex items-center space-x-2 mb-8">
            <span className="text-2xl font-serif italic text-text-bright tracking-tight">StayFlow.</span>
          </div>
          <p className="text-text-dim text-xs uppercase tracking-[2px] leading-relaxed max-w-sm">
            Curating silent sanctuaries and architectural marvels for the contemporary voyager.
          </p>
        </div>
        
        <div>
          <h3 className="text-[10px] uppercase tracking-[4px] text-accent font-bold mb-8">Archives</h3>
          <ul className="space-y-4 text-[11px] uppercase tracking-[2px] text-text-dim font-medium">
            <li><a href="#" className="hover:text-white transition-colors">Nordic Retreats</a></li>
            <li><a href="#" className="hover:text-white transition-colors">Desert Sanctuaries</a></li>
            <li><a href="#" className="hover:text-white transition-colors">Urban Monoliths</a></li>
          </ul>
        </div>
        
        <div>
          <h3 className="text-[10px] uppercase tracking-[4px] text-accent font-bold mb-8">Connect</h3>
          <ul className="space-y-4 text-[11px] uppercase tracking-[2px] text-text-dim font-medium">
            <li><a href="#" className="hover:text-white transition-colors">Journal</a></li>
            <li><a href="#" className="hover:text-white transition-colors">Aesthetics</a></li>
            <li><a href="#" className="hover:text-white transition-colors">Inquiries</a></li>
          </ul>
        </div>
      </div>
      
      <div className="max-w-7xl mx-auto mt-24 pt-12 border-t border-white/5 flex flex-col md:flex-row justify-between items-center text-[9px] uppercase tracking-[3px] text-text-dim/50">
        <p>&copy; {new Date().getFullYear()} StayFlow Studio. All rights reserved.</p>
        <div className="flex space-x-8 mt-6 md:mt-0 grayscale opacity-50">
          <Instagram className="h-4 w-4 hover:text-white transition-colors cursor-pointer" />
          <Twitter className="h-4 w-4 hover:text-white transition-colors cursor-pointer" />
        </div>
      </div>
    </footer>
  );
}
